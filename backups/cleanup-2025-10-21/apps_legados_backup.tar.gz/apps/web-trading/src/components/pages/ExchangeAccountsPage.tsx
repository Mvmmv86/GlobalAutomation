import React, { useState } from 'react'
import { Plus, Settings, Trash2, Wifi } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../atoms/Card'
import { Button } from '../atoms/Button'
import { Badge } from '../atoms/Badge'
import { LoadingSpinner } from '../atoms/LoadingSpinner'
import { useExchangeAccounts, useCreateExchangeAccount } from '@/hooks/useApiData'
import { CreateExchangeAccountModal, ExchangeAccountData } from '../molecules/CreateExchangeAccountModal'
import { ConfigureAccountModal, AccountConfiguration } from '../molecules/ConfigureAccountModal'

const ExchangeAccountsPage: React.FC = () => {
  const [apiStatus, setApiStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle')
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isConfigureModalOpen, setIsConfigureModalOpen] = useState(false)
  const [selectedAccountId, setSelectedAccountId] = useState<string>('')
  const [selectedAccountName, setSelectedAccountName] = useState<string>('')
  const [selectedExchange, setSelectedExchange] = useState<string>('')

  // API Data hooks
  const { data: accountsApi, isLoading: loadingAccounts, error: accountsError, refetch } = useExchangeAccounts()
  const createAccountMutation = useCreateExchangeAccount()

  const testApiConnection = async () => {
    setApiStatus('testing')
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/`)
      if (response.ok) {
        setApiStatus('success')
      } else {
        setApiStatus('error')
      }
    } catch (error) {
      setApiStatus('error')
    }
  }

  const handleCreateAccount = () => {
    setIsCreateModalOpen(true)
  }

  const handleSubmitAccount = async (data: ExchangeAccountData) => {
    try {
      await createAccountMutation.mutateAsync(data)
      setIsCreateModalOpen(false)
      alert(`✅ Conta criada com sucesso! ${data.name} foi configurada na ${data.exchange}`)
      refetch()
    } catch (error: any) {
      alert(`❌ Erro ao criar conta: ${error.message || "Não foi possível criar a conta"}`)
    }
  }

  const handleConfigureAccount = (accountId: string) => {
    const account = accounts.find(acc => acc.id === accountId)
    if (account) {
      setSelectedAccountId(accountId)
      setSelectedAccountName(account.name)
      setSelectedExchange(account.exchange)
      setIsConfigureModalOpen(true)
    }
  }

  const handleSubmitConfiguration = async (config: AccountConfiguration) => {
    try {
      // Here you would normally save to backend
      console.log('💾 Saving configuration for account:', selectedAccountId, config)
      setIsConfigureModalOpen(false)
      alert(`✅ Configurações salvas com sucesso para ${selectedAccountName}!`)
    } catch (error: any) {
      alert(`❌ Erro ao salvar configurações: ${error.message || "Não foi possível salvar"}`)
    }
  }

  const handleDeleteAccount = (accountId: string) => {
    if (confirm('Tem certeza que deseja deletar esta conta?')) {
      alert(`Conta ${accountId} deletada - implementação em breve!`)
    }
  }

  // Mock data for fallback
  const mockAccounts = [
    {
      id: '1',
      name: 'Binance Main',
      exchange: 'binance',
      testnet: false,
      isActive: true,
    },
    {
      id: '2',
      name: 'Binance Testnet',
      exchange: 'binance',
      testnet: true,
      isActive: true,
    },
  ]

  // Use real data when available, fallback to mock data
  const accounts = accountsApi || mockAccounts

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Exchange Accounts
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Gerencie suas contas de exchanges
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            onClick={testApiConnection}
            variant={apiStatus === 'success' ? 'success' : apiStatus === 'error' ? 'danger' : 'outline'}
            disabled={apiStatus === 'testing'}
          >
            <Wifi className="w-4 h-4 mr-2" />
            {apiStatus === 'testing' ? 'Testando...' : 'Testar API'}
          </Button>
          <Button onClick={handleCreateAccount}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Conta
          </Button>
        </div>
      </div>

      {/* API Error Banner */}
      {accountsError && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
          <p className="text-yellow-800 dark:text-yellow-200 text-sm">
            ⚠️ API indisponível - usando dados demo
          </p>
        </div>
      )}

      {/* Loading State */}
      {loadingAccounts ? (
        <div className="flex items-center justify-center py-12">
          <LoadingSpinner />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {accounts.map((account) => (
          <Card key={account.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{account.name}</CardTitle>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleConfigureAccount(account.id)}
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleDeleteAccount(account.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <CardDescription>
                Exchange: {account.exchange.charAt(0).toUpperCase() + account.exchange.slice(1)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2">
                <Badge variant={account.isActive ? 'success' : 'secondary'}>
                  {account.isActive ? 'Ativa' : 'Inativa'}
                </Badge>
                <Badge variant={account.testnet ? 'warning' : 'default'}>
                  {account.testnet ? 'Testnet' : 'Mainnet'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
        </div>
      )}

      {/* Create Account Modal */}
      <CreateExchangeAccountModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleSubmitAccount}
        isLoading={createAccountMutation.isPending}
      />

      {/* Configure Account Modal */}
      <ConfigureAccountModal
        isOpen={isConfigureModalOpen}
        onClose={() => setIsConfigureModalOpen(false)}
        onSubmit={handleSubmitConfiguration}
        accountId={selectedAccountId}
        accountName={selectedAccountName}
        exchange={selectedExchange}
        isLoading={false}
      />
    </div>
  )
}

export default ExchangeAccountsPage